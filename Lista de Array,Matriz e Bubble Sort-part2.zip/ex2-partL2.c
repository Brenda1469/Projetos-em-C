#include <stdio.h>

int main()
{
    int vet1[10];
    int vet2[10];
    int vet3[10];
    int vet4[10];
    int vet5[10];
    int i;
    for (i = 0; i < 10; i++)
    {
        printf("Digete os valores do primeiro vetor: \n");
        scanf("%d", &vet1[i]);
    }
    for (i = 0; i < 10; i++)
    {
        printf("Digete os valores do segundo  vetor: \n");
        scanf("%d", &vet2[i]);
    }
    for (i = 0; i < 10; i++)
    {

        vet3[i] = vet1[i] + vet2[i];
        vet4[i] = vet1[i] * vet2[i];
    }

    for (i = 0; i < 10; i++)
    {
        if (vet2 != 0)
        {
            vet5[i] = vet1[i] / vet2[i];
        }
        else
        {
            vet5[i] = 0;
        }
    }

    printf("O resultado e: \n");
    for (i = 0; i < 10; i++)
    {
        printf("O resultado do vetor 3[%d] e: %d \n", i, vet3[i]);
        printf("O resultado do vetor 4[%d] e: %d \n", i, vet4[i]);
        printf("O resultado do vetor 5[%d] e: %d \n", i, vet5[i]);
        printf("\n");
    }

    return 0;
}