#include <stdio.h>

int main()
{
    int vet[10];
    int i;
    int j;
    int cont = 0;
    int aux;

    for (i = 0; i < 10; i++)
    {
        printf("Digete o %d° valor do vetor: \n", i + 1);
        scanf("%d", &vet[i]);
    }

    printf(" \n O vetor antes da ordenação e:\n");
    for (i = 0; i < 10; i++)
    {
        printf("%d", vet[i]);
    }

    for (i = 0; i < 10; i++)
    {
        for (j = i + 1; j < 10; j++)
        {
            if (vet[j] < vet[i])
            {
                aux = vet[j]; // aqui ira ocorrer as trocas de valores
                vet[j] = vet[i];
                vet[i] = aux;

                cont++;
            }
        }
    }
    printf(" \n Teve %d trocas: \n", cont);
    printf(" \n O novo vetor e: \n");
    for (i = 0; i < 10; i++)
    {
        printf("%d", vet[i]);
    }

    return 0;
}