#include <stdio.h>

int main()
{
    int mat[4][5];
    int i;
    int j;
    int k;
    int aux;

    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            printf("Digite o valor para a linha %d e coluna %d:\n", i + 1, j + 1);
            scanf("%d", &mat[i][j]);
        }
    }

    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5 - 1; j++)
        {
            for (k = j + 1; k < 5; k++)
            {
                if (mat[i][k] > mat[i][j])
                {
                    aux = mat[i][k];
                    mat[i][k] = mat[i][j];
                    mat[i][j] = aux;
                }
            }
        }
    }

    printf("\nA nova matriz ordenada de forma decrescente é:\n");
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }

    return 0;
}