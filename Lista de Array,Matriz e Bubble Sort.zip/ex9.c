#include <stdio.h>

int main()
{
    float mat[3][6];
    int i;
    int j;
    float soma = 0;

    float media = 0;

    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 6; j++)
        {
            printf("Digite o valor para a linha %d e coluna %d: ", i + 1, j + 1);
            scanf("%f", &mat[i][j]);
        }
    }

    for (i = 0; i < 3; i++)
    {
        soma += mat[i][0] + mat[i][2] + mat[i][4];
    }
    printf("A soma dos elementos da colunas impares sao: %.2f \n", soma);

    for (i = 0; i < 3; i++)
    {
        media += mat[i][1] + mat[i][3];
    }
    media = media / 2;
    printf("A media dos elementos da colunas dois e quatro sao: %.2f \n", media);
    for (i = 0; i < 3; i++)
    {
        mat[i][5] = mat[i][0] + mat[i][1];
    }

    printf("A substituição dos elementos da sexta coluna pela soma das colunas 1 e 2:\n");
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 6; j++)
        {
            printf("%.2f ", mat[i][j]);
        }
        printf(" \n");
    }
    return 0;
}
