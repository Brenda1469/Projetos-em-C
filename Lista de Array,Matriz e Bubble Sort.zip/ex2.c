#include <stdio.h>
int main()
{
    int x[5];
    int y[5];
    int aux[5];
    int aux2[5];
    int aux3[5];
    int aux4[5];
    int aux5[10];

    for (int i = 0; i < 5; i++)
    {
        printf("Digete os valores do primeiro vetor: \n");
        scanf("%d", &x[i]);
    }
    for (int i = 0; i < 5; i++)
    {
        printf("Digete os valores do segundo vetor: \n");
        scanf("%d", &y[i]);
    }
    for (int i = 0; i < 5; i++)
    {

        aux[i] = x[i] + y[i];
        aux2[i] = x[i] * y[i];
        aux3[i] = x[i] - y[i];

        if (x[i] == y[i])
        {
            aux4[i] = x[i];
        }
        else
        {
            aux4[i] = 0;
        }
        printf("\n A soma dos elementos nas posições %d é: %d\n", i, aux[i]);
        printf("O produto dos elementos nas posições %d é: %d\n", i, aux2[i]);
        printf("A diferença dos elementos nas posições %d é: %d\n", i, aux3[i]);
        if (aux4[i] != 0)
        {
            printf("\nA interseção dos elementos nas posições %d é: %d\n", i, aux4[i]);
        }
        else
        {
            printf("\nNão há interseção nos elementos nas posições %d.\n", i);
        }
    }
    int index = 0; // index facilita a organização e a inserção ordenada dos elementos durante a operação de união dos vetores no programa.
    for (int i = 0; i < 5; i++)
    {

        aux5[index++] = x[i];
        aux5[index++] = y[i];
    }

    printf("A uniao dos vetores e: \n");
    for (int i = 0; i < 10; i++)
    {
        printf("%d", aux5[i]);
    }
    printf("\n");

    return 0;
}