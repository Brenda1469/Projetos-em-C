#include <stdio.h>

int main()
{
    int vet[6];
    int aux[6];
    int aux2;
    int cont = 0;
    int i;
    for (i = 0; i < 6; i++)
    {
        printf("Digete os valorea: \n");
        scanf("%d", &vet[i]);
    }

    for (i = 0; i < 6; i++)
    {
        if (vet[i] % 2 == 0)
        {
            aux[i] = vet[i];

            aux2 += aux[i];
            printf("Os valores pares sao: %d \n", aux[i]);
        }
    }
    printf("A soma dos valores pares sao: %d \n", aux2);

    for (i = 0; i < 6; i++)
    {
        if (vet[i] % 2 != 0)
        {
            cont++;
            printf("Os valores impares sao: %d \n", vet[i]);
        }
    }
    printf("A quantidade de valores impares sao: %d \n", cont);

    return 0;
}
