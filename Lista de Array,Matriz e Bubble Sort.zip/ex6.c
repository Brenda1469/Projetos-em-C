#include <stdio.h>

int main()
{
    int vet[10];
    int i;
    int j;
    int aux;
    for (i = 0; i < 10; i++)
    {
        printf("Digete os valores: \n");
        scanf("%d", &vet[i]);
    }
    for (i = 0; i < 10; i++)
    {
        for (j = i + 1; j < 10; j++)
        {
            if (vet[j] < vet[i])
            {
                aux = vet[j]; // aqui ira ocorrer as trocas de valores
                vet[j] = vet[i];
                vet[i] = aux;
            }
        }
    }
    printf("Os valores desse vetor sao:\n ");
    for (i = 0; i < 10; i++)
    {
        printf("%d \n", vet[i]);
    }
    return 0;
}
