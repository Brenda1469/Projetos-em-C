#include <stdio.h>

int main()
{
    int mat[5][5];
    int x = 0;

    int coluna = -1;
    int linha = -1;

    printf("Digete o valor de X: \n");
    scanf("%d", &x);

    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            printf("Digite o valor para a linha %d e coluna %d:\n", i + 1, j + 1);
            scanf("%d", &mat[i][j]);
        }
    }
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            if (x == mat[i][j])
            {

                coluna = j;
                linha = i;
            }
        }
    }
    if (linha != -1 && coluna != -1)
    {
        printf("O valor de X esta na linha %d e na coluna %d: \n", linha + 1, coluna + 1);
    }
    else
    {
        printf("O valor de X nao foi encontrado na matriz.\n");
    }

    return 0;
}
