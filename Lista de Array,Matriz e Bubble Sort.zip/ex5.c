#include <stdio.h>

int main()
{
    int alu[10];
    float alt[10];
    float maior = 0;
    float menor = 0;

    int num;
    int num2;
    printf("Digete os numeros dos alunos: \n");
    for (int i = 0; i < 10; i++)
    {
        scanf("%d", &alu[i]);
    }
    printf("Digete as alturas dos alunos: \n");
    for (int i = 0; i < 10; i++)
    {
        scanf("%f", &alt[i]);
        if (i == 0)
        {
            maior = alt[i];
            menor = alt[i];
        }
    }
    for (int i = 0; i < 10; i++)
    {
        if (alt[i] > maior)
        {
            maior = alt[i];
            num = alu[i];
        }
    }
    printf("O aluno numero %d tem a maior altura: %f metros \n", num, maior);
    for (int i = 0; i < 10; i++)
    {
        if (alt[i] < menor)
        {
            menor = alt[i];
            num2 = alu[i];
        }
    }
    printf("O aluno numero %d tem a menor altura: %f metros \n", num2, menor);

    return 0;
}