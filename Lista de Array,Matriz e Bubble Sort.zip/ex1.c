#include <stdio.h>

int main()
{
    int vet[50];
    for (int i = 0; i < 50; i++)
    {
        vet[i] = i + i * i;
    }
    printf("Os numeros imapres desse vetor sao: \n");
    for (int i = 1; i < 50; i += 2) //posiçao impares
    {

        printf("%d ", vet[i]);
    }
    printf(" \n Os numeros pares desse vetor sao: \n");
    for (int i = 0; i < 50; i += 2) //posiçoes pares
    {

        printf("%d ", vet[i]);
    }

    return 0;
}