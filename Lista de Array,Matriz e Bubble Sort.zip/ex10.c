#include <stdio.h>

int main()
{
    int mat[5][4];
    int notaf = -1;
    int matriculatnf = 0;
    ;
    float somanf = 0;
    printf("Digite as informacoes dos alunos:\n");
    for (int i = 0; i < 5; i++)
    {
        printf("Aluno %d:\n", i + 1);
        printf("Numero de matricula: ");
        scanf("%d", &mat[i][0]);
        printf("Media das provas: ");
        scanf("%d", &mat[i][1]);
        printf("Media dos trabalhos: ");
        scanf("%d", &mat[i][2]);

        mat[i][3] = mat[i][1] + mat[i][2];

        if (mat[i][3] > notaf)
        {
            notaf = mat[i][3];
            matriculatnf = mat[i][0];
        }

        somanf += mat[i][3];
    }
    printf("Numero de matricula do aluno com maior nota final: %d \n", matriculatnf);

    float medianf = somanf / 5;
    printf("A media das notas dos alunos e: %f \n", medianf);

    return 0;
}